//
//  student.h
//  MU-system
//
//  Created by  mohammd al-badiah on 16/09/2025.
//

#pragma once
#include <string>
using namespace std ;


class student {
    
    
    private :
    int   student_id_v , student_course_v ;
    string student_major_v , student_name_v ;
    
    public :
    
    student();
    ~student();
    
    // setter functions
    
    void set_student_id(int stsid);
    void set_student_course(int stsc);
    void set_student_major(string stsm);
    void set_student_name(string stsn);
    
    
    //  getter functions
    
    int get_student_id();
    int get_student_course();
    string get_student_major();
    string get_student_name();
    
    
    
    
};
