//
//  student.cpp
//  MU-system
//
//  Created by  mohammd al-badiah on 16/09/2025.
//

#include <iostream>
#include "student.h"
#include <string>
using namespace std ;


student::student(){
    
    student_id_v = 000 ;
    student_course_v = 000;
    student_major_v = "None";
    student_name_v = "None";
}

student::~student(){
    cout << "object student DEAD " << endl;
    
}

 // setter functions

void student::set_student_id(int stsid){
    
    student_id_v = stsid;
    
}

void student::set_student_course(int stsc){
    
    student_course_v = stsc;
}

void student::set_student_major(string stsm){
    
    student_major_v = stsm ;
}

void student::set_student_name(string stsn){
    
    student_name_v = stsn ;
}



// getter functions


int student::get_student_id(){
    return student_id_v ;
}

int student::get_student_course(){
    return student_course_v ;
}

string student::get_student_major(){
    return student_major_v ;
}

string student::get_student_name(){
    return student_name_v;
}
