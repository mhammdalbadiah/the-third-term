//
//  course.h
//  MU-system
//
//  Created by  mohammd al-badiah on 16/09/2025.
//

#pragma once
#include <string>
using namespace std ;

class course {
    
    
    private :
    
    int course_id_v , credit_v  ;
    string course_name_v ;
    
    
    public :
    
    
    course();
    ~course();
    
    
    void set_course_id( int id);   // setter function
    void set_credit( int c );
    void set_course_name( string n);
    
    
    int get_course_id();   // getter function
    int get_credit();
    string get_course_name();
    
    
};

