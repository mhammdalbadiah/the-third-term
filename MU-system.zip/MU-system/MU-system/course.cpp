 
#include <iostream>
#include "course.h"
#include <string>
using namespace std ;



/*
 
 void set_course_id( int id);   // setter function
 void set_credit( int c );
 void set_course_name( string n);
 
 
 int get_course_id();   // getter function
 int get_credit();
 string get_course_name();
 
 */

   
course::course(){
    
    course_id_v = 000 ;
    credit_v = 000 ;
    course_name_v = "None";
}

course::~course(){
    
    cout << "object course DEAD " << endl;
}


 // setter functions

void course::set_course_id( int id){

    course_id_v = id ;
}

void course::set_credit(int c){
    
    credit_v = c ;
}

void course::set_course_name(string n ){
    
    course_name_v = n ;
}




// getter functions



int course::get_credit(){
    return credit_v;
}


int course::get_course_id(){
    
    return course_id_v;
}

string course::get_course_name(){
    
    return course_name_v ;
}
