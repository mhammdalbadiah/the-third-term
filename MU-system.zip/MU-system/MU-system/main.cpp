//
//  main.cpp
//  MU-system
//
//  Created by  mohammd al-badiah on 16/09/2025.
//

#include <iostream>
#include <string>
#include "course.h"
#include "Doctor.h"
#include "student.h"




int main (){
    
    // switch v
    
    int x,y;
    
    
    // student v
    
    
    int stsid  , stsc ;
    string stsm, stsn;
    
    // doctor v
    
    int docid , docc ;
    string docm , docname ;
    
    // course v
    
   
    int id , c ;
    string n ;
    
    
    
    // class object
    
    student s1;
    doctor d1;
    course c1 ;
    
    while (true) {
        
        
        cout << "wellcome to our program ! " << endl;
        cout << " to sign in as student (1) " << endl;
        cout << " to sign in as doctor  (2) " << endl;
        cout << " to enter a new course (3) " << endl;
        cout << " to Exit (4) " << endl;
        cout << ":";
        cin >> x ;
        
        if ( x == 4 )
            break;
        
        switch (x) {
            case 1:
                
                
                
                
                cout << "please enter your id number : " << endl;
                cin >> stsid ;
                s1.set_student_id( stsid);
                
                cout << "please enter your course number : " << endl;
                cin >> stsc ;
                s1.set_student_course( stsc);
                
                cout << "please enter your major : " << endl;
                cin >> stsm;
                s1.set_student_major( stsm);
                
                
                cout << "please enter your name : " << endl;
                cin >> stsn;
                s1.set_student_name( stsn);
                
                cout << "to print press 1 : " << endl;
                cin >> y ;
                
                if (y==1){
                    
                    cout << s1.get_student_name() << "    " << s1.get_student_id() << endl;
                    cout << s1.get_student_major()<< "    " << s1.get_student_course() << endl;
            
                }
                
                break;
                
                
                
            case 2 :
                
                
                cout << "please enter your id number : " << endl;
                cin >> docid ;
                d1.set_doc_id(docid);
                
                cout << "please etner your course number : " << endl;
                cin >> docc ;
                d1.set_doc_course( docc);
                
                cout << "please enter your major : " << endl;
                cin >> docm ;
                d1.set_doc_major( docm);
                
                cout << "plesae enter your name : " << endl;
                cin >> docname ;
                d1.set_doc_name(docname);
                
                
                
                cout << "to print press 1 : " << endl;
                cin >> y ;
                
                if (y==1){
                    
                    cout << d1.get_doc_name() << "    " << d1.get_doc_id() << endl;
                    cout << d1.get_doc_major()<< "    " << d1.get_doc_course() << endl;
            
                }
                
                
                break;
                
                
                
            case 3:
                
                cout << "enter the course ID : " << endl;
                cin >> id ;
                c1.set_course_id( id);
                
                cout << "enter the course credit : " << endl;
                cin >> c ;
                c1.set_credit(c);
                
                cout << "enter the course name : " << endl;
                cin >> n ;
                c1.set_course_name( n);
                
                
                
                cout << "to print press 1 : " << endl;
                cin >> y ;
                
                if (y==1){
                    
                    cout << c1.get_course_name() << "    " << c1.get_course_id() << endl;
                    cout << c1.get_credit() << endl;
                    
                }
                
                
                
        }
        
        
        
        
    }
      
    
        
    
    
    
    
    
    return 0 ;
}
