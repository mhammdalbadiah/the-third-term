//
//  Doctor.cpp
//  MU-system
//
//  Created by  mohammd al-badiah on 16/09/2025.
//

#include <iostream>
#include "Doctor.h"
#include <string>
using namespace std ;



 /*
  int doc_id_v , doc_course_v;
  string doc_major_v , doc_name_v ;
     */

doctor::doctor(){
    
    doc_id_v = 000;
    doc_course_v = 000;
    doc_major_v = "None";
    doc_name_v = "None" ;
    
}

doctor::~doctor(){
    
    cout << "object doctor DEAD " << endl;
    
}


 // setter function


/*
 
 void set_doc_id(int docid);
 void set_doc_course(int docc);
 void set_doc_major(string docm);
 void set_doc_name(string docname);
 
 */

void doctor::set_doc_id(int docid){
    
    doc_id_v = docid ;
}

void doctor::set_doc_course(int docc){
    
    doc_course_v = docc ;
}

void doctor::set_doc_major(string docm){
    
    doc_major_v = docm ;
}

void doctor::set_doc_name(string docname){
    
    doc_name_v = docname ;
}



// getter functions


/*
 int get_doc_id();
 int get_doc_course();
 string get_doc_major();
 string get_doc_name();
 */

int doctor::get_doc_id(){
    return doc_id_v ;
}

int doctor::get_doc_course(){
    return doc_course_v ;
}

string doctor::get_doc_major(){
    return doc_major_v ;
}

string doctor::get_doc_name(){
    return doc_name_v ;
}
