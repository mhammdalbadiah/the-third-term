//
//  Doctor.h
//  MU-system
//
//  Created by  mohammd al-badiah on 16/09/2025.
//

#pragma once
#include <string>
using namespace std ;

class doctor{
    
    private :
       
    int doc_id_v , doc_course_v;
    string doc_major_v , doc_name_v ;
       
    public :
    
    doctor();
    ~doctor();
    
    
    // setter functions
    
    void set_doc_id(int docid);
    void set_doc_course(int docc);
    void set_doc_major(string docm);
    void set_doc_name(string docname);
    
    
    //  getter functions
    
    
    int get_doc_id();
    int get_doc_course();
    string get_doc_major();
    string get_doc_name();
    
    
};
